<table class="company two-column">
    <tbody>
    <tr>
        <td style="float:right !important" class="logo" align="right"><?php $this->get_company_logo_html(); ?></td>
    </tr>
    </tbody>
</table>
<?php
//$order = new WC_Order( $order_id );
$items = $this->order->get_items();
foreach ( $items as $item ) {
    $product_name = $item['name'];
    $product_id = $item['product_id'];
    $product_variation_id = $item['variation_id'];
	$product_expirary_date = get_post_meta( $product_id, '_expire_date',true);  
	
	$product_expirary_time = get_post_meta(  $product_id, '_expire_time', true);
	if(!$product_expirary_date)
	{
		$dagstilbud_from_date = get_post_meta(  $product_id, '_dagstilbud_from_date',true);     
		$dagstilbud_from_time = get_post_meta( $product_id, '_dagstilbud_from_time', true);
		$dagstilbud_to_date = get_post_meta( $product_id, '_dagstilbud_to_date',true);     
		$dagstilbud_to_time = get_post_meta(  $product_id, '_dagstilbud_to_time', true);
		$product_expirary_date =  $dagstilbud_from_date.' - '.$dagstilbud_to_date;	
		$product_expirary_time =  $dagstilbud_from_time.' - '.$dagstilbud_to_time;	
	}
}
$post_author = get_post_field( 'post_author', $product_id);


$deal_owner_first_name = get_user_meta( $post_author, 'billing_first_name', true );
$deal_owner_last_name = get_user_meta( $post_author, 'billing_last_name', true );
$deal_owner_addr1 = get_user_meta( $post_author, 'billing_address_1', true );
$deal_owner_addr2 = get_user_meta( $post_author, 'billing_address_2', true );
$deal_owner_pin = get_user_meta( $post_author, 'billing_postcode', true );
$deal_owner_by = get_user_meta( $post_author, 'billing_city', true );
$deal_owner_country = get_user_meta( $post_author, 'billing_country', true );
$deal_owner_tlf = get_user_meta( $post_author, 'billing_phone', true );


?>
<h3>Dit tilbud er blevet købt</h3>
Vi håber, at din kunde bliver glad for sin behandling.<br>
Rigtig god fornøjelse
<h2>Stayfab!</h2>

<table class="tg" style="font-family:Helvetica !important;font-size:9px !important;">
  <tr style="align:left !important;font-family:Helvetica !important;font-size:9px !important;">
    <th class="tg-9hbo" colspan="2" align="left" bgcolor="#9E9E9E" color="#000">Faktura nr. <?php echo $this->get_formatted_number(); ?>
    <br><?php printf( __( 'Order Number: %s', $this->textdomain ), $this->order->get_order_number() ); ?>
    <br><?php printf( __( 'Order Date: %s', $this->textdomain ), $this->get_formatted_order_date() ); ?></th>
  </tr>
  <tr>
    <td color="#000" class="tg-9hbo">Solgt til:</td>
    <td color="#000" class="tg-9hbo">Behandling hos:</td>
  </tr>
  <tr>
  
    <td color="#000" class="tg-yw4l">
			<?php echo $this->order->get_formatted_billing_address(); ?><br/>
            <?php echo $this->order->billing_phone; ?>
    </td>
    <td color="#000" class="tg-yw4l">
		<?php 
			echo $deal_owner_first_name.' '.$deal_owner_last_name.'<br>' ; 
			echo $deal_owner_addr1.' '.$deal_owner_addr2.'<br>' ; 
			echo $deal_owner_pin.' '.$deal_owner_by.'<br>' ; 
			echo $deal_owner_country.'<br>' ; 
			echo 'Tlf: '.$deal_owner_tlf ; 
		
		?>
    </td>
  </tr>
  <tr>
    <td color="#000" class="tg-9hbo">Betalingsmetode</td>
    <td color="#000" class="tg-9hbo">Behandlings type +dato og tid og sted</td>
  </tr>
  <tr>
    <td color="#000" class="tg-yw4l"><?php echo $this->order->payment_method_title; ?></td>
    <td color="#000" class="tg-3ojc">
    <?php echo $product_name;?>
    <br>Sted:
    <br>
	<?php   echo $deal_owner_first_name.' '.$deal_owner_last_name.'<br>' ; 
			echo $deal_owner_addr1.' '.$deal_owner_addr2.'<br>' ; 
			echo $deal_owner_pin.' '.$deal_owner_by.'<br>' ; 
			//echo $deal_owner_country.'<br>' ; 
			echo 'Tlf: '.$deal_owner_tlf ; 
	?>
    <br>
    <div style="color:red">
    Dato: <?php echo $product_expirary_date ;?>
    <br>Tid: <?php echo $product_expirary_time; ?>
    </div>
    </td>
  </tr>
</table>

<!--                                Body content                                -->
<?php //echo $this->outlining_columns_html(); ?>
<br><br>
<table  class="products small-font">
        <thead>
        <tr color="#000" bgcolor="#9E9E9E" class="table-headers">
            <th color="#000" class="align-left"><?php _e( 'Produkt', $this->textdomain ); ?></th>
            <?php
            //if( $this->template_options['bewpi_show_sku'] ) {
                echo '<th color="#000" class="align-left">' . __( "Varenummer", $this->textdomain ) . '</th>';
           // }
            ?>
	        <th color="#000" class="align-left"><?php _e( 'Pris', $this->textdomain ); ?></th>
            <th color="#000" class="align-left"><?php _e( 'Antal', $this->textdomain ); ?></th>
 			<th color="#000" class="align-left"><?php _e( 'Moms', $this->textdomain ); ?></th>
	        <!-- Tax -->
	        <?php
	       /* $order_taxes    = $this->order->get_taxes();
	        if ( $this->template_options['bewpi_show_tax'] && wc_tax_enabled() && empty( $legacy_order ) && ! empty( $order_taxes ) ) :
		        foreach ( $order_taxes as $tax_id => $tax_item ) :
                    $tax_label = __( 'VAT', $this->textdomain );
			        $column_label = ! empty( $tax_item['label'] ) ? $tax_item['label'] : $tax_label;
			        ?>
			        <th class="align-left">
				        <?php echo $column_label; ?>
			        </th>
		        <?php
		        endforeach;
	        endif;*/
	        ?>

            <th color="#000" class="align-right"><?php _e( 'Total', $this->textdomain ); ?></th>
        </tr>
        </thead>
        <tbody>
            <?php foreach( $this->order->get_items( 'line_item' ) as $item_id => $item ) {
                $product = wc_get_product( $item['product_id'] );
				
				 ?>
                <tr class="product-row">
                    <td color="#000">
                        <?php echo $product->get_title(); ?>
                        <?php
                        global $wpdb;

                        if ( $metadata = $this->order->has_meta( $item_id ) ) {
                            foreach ( $metadata as $meta ) {

                                // Skip hidden core fields
                                if ( in_array( $meta['meta_key'], apply_filters( 'woocommerce_hidden_order_itemmeta', array(
                                    '_qty',
                                    '_tax_class',
                                    '_product_id',
                                    '_variation_id',
                                    '_line_subtotal',
                                    '_line_subtotal_tax',
                                    '_line_total',
                                    '_line_tax',
                                ) ) ) ) {
                                    continue;
                                }

                                // Skip serialised meta
                                if ( is_serialized( $meta['meta_value'] ) ) {
                                    continue;
                                }

                                // Get attribute data
                                if ( taxonomy_exists( wc_sanitize_taxonomy_name( $meta['meta_key'] ) ) ) {
                                    $term               = get_term_by( 'slug', $meta['meta_value'], wc_sanitize_taxonomy_name( $meta['meta_key'] ) );
                                    $meta['meta_key']   = wc_attribute_label( wc_sanitize_taxonomy_name( $meta['meta_key'] ) );
                                    $meta['meta_value'] = isset( $term->name ) ? $term->name : $meta['meta_value'];
                                } else {
                                    $meta['meta_key']   = apply_filters( 'woocommerce_attribute_label', wc_attribute_label( $meta['meta_key'], $product ), $meta['meta_key'] );
                                }

                                echo '<div class="item-attribute"><span style="font-weight: bold;">' . wp_kses_post( rawurldecode( $meta['meta_key'] ) ) . ': </span>' . wp_kses_post( rawurldecode( $meta['meta_value'] ) ) . '</div>';
                            }
                        }
                        ?>
                    </td>
                        <?php
                       // if ( $this->template_options['bewpi_show_sku'] ) :
                            echo '<td>';
                            echo ( $product->get_sku() != '' ) ? $product->get_sku() : '-';
                            echo '</td>';
                       // endif;
                        ?>
                    <td color="#000">
                        <?php
                        if ( isset( $item['line_total'] ) ) {
                            if ( isset( $item['line_subtotal'] ) && $item['line_subtotal'] != $item['line_total'] ) {
                                echo '<del>' . wc_price( $this->order->get_item_subtotal( $item, false, true ), array( 'currency' => $this->order->get_order_currency() ) ) . '</del> ';
                            }
                            echo wc_price( $this->order->get_item_total( $item, false, true ), array( 'currency' => $this->order->get_order_currency() ) );
                        }
                        ?>
                    </td>
                    <td color="#000">
                        <?php
                        echo $item['qty'];

                        if ( $refunded_qty = $this->order->get_qty_refunded_for_item( $item_id ) )
                            echo '<br/><small class="refunded">-' . $refunded_qty . '</small>';
                        ?>
                    </td>
                    <td color="#000">
                        <?php
                        echo $this->order->get_total_tax();
                        ?>
                    </td>
                    <?php /*?><?php
                    if ( empty( $legacy_order ) && wc_tax_enabled() && $this->template_options['bewpi_show_tax'] ) :
                        $line_tax_data = isset( $item['line_tax_data'] ) ? $item['line_tax_data'] : '';
                        $tax_data      = maybe_unserialize( $line_tax_data );

                        foreach ( $this->order->get_taxes() as $tax_item ) :
                            $tax_item_id       = $tax_item['rate_id'];
                            $tax_item_total    = isset( $tax_data['total'][ $tax_item_id ] ) ? $tax_data['total'][ $tax_item_id ] : '';
                            $tax_item_subtotal = isset( $tax_data['subtotal'][ $tax_item_id ] ) ? $tax_data['subtotal'][ $tax_item_id ] : '';
                            ?>

                            <td class="item-tax">
                                <?php
                                if ( '' != $tax_item_total ) {
                                    if ( isset( $tax_item_subtotal ) && $tax_item_subtotal != $tax_item_total ) {
                                        echo '<del>' . wc_price( wc_round_tax_total( $tax_item_subtotal ), array( 'currency' => $this->order->get_order_currency() ) ) . '</del> ';
                                    }

                                    echo wc_price( wc_round_tax_total( $tax_item_total ), array( 'currency' => $this->order->get_order_currency() ) );
                                } else {
                                    echo '&ndash;';
                                }

                                if ( $refunded = $this->order->get_tax_refunded_for_item( $item_id, $tax_item_id ) ) {
                                    echo '<br/><small class="refunded">-' . wc_price( $refunded, array( 'currency' => $this->order->get_order_currency() ) ) . '</small>';
                                }
                                ?>
                            </td>

                            <?php
                        endforeach;
                    endif;
                    ?><?php */?>
                    <td color="#000" class="align-right item-total" width="">
                        <?php
                        if ( isset( $item['line_total'] ) ) {
                            $incl_tax = (bool)$this->template_options[ 'bewpi_display_prices_incl_tax' ];

                            if ( isset( $item['line_subtotal'] ) && $item['line_subtotal'] != $item['line_total'] ) {
                                echo '<del>' . wc_price( $this->order->get_line_subtotal( $item, $incl_tax, true ), array( 'currency' => $this->order->get_order_currency() ) ) . '</del> ';
                            }

                            echo wc_price( $this->order->get_line_total( $item, $incl_tax, true ), array( 'currency' => $this->order->get_order_currency() ) );
                        }

                        if ( $refunded = $this->order->get_total_refunded_for_item( $item_id ) ) {
                            echo '<br/><small class="refunded">-' . wc_price( $refunded, array( 'currency' => $this->order->get_order_currency() ) ) . '</small>';
                        }
                        ?>
                    </td>
                </tr>
            <?php } ?>
            <!-- Space -->
            <tr class="space">
	        <td colspan="<?php echo $this->columns_count; ?>"></td>
        </tr>
        <!-- Table footers -->
        <!-- Subtotal -->
       <?php /*?> <?php if( $this->template_options['bewpi_show_subtotal'] && (bool)$this->template_options[ 'bewpi_display_prices_incl_tax' ] ) { ?><?php */?>
            <tr class="subtotal after-products">
                <td colspan="<?php echo $this->colspan['left']; ?>"></td>
                <td color="#000" colspan="<?php echo $this->colspan['right_left']; ?>"><?php _e( 'Total:', $this->textdomain ); ?></td>
                <td color="#000" colspan="<?php echo $this->colspan['right_right']; ?>" class="align-right"><?php echo wc_price( $this->get_subtotal_incl_tax(), array( 'currency' => $this->order->get_order_currency() ) ); ?></td>
            </tr>
       <?php /*?> <?php } ?><?php */?>
        <!-- Discount -->
       <?php /*?> <?php if( $this->template_options['bewpi_show_discount'] && $this->order->get_total_discount() !== 0.00 ) { ?><?php */?>
            <tr class="discount after-products">
                <td colspan="<?php echo $this->colspan['left']; ?>"></td>
                <td color="#000" colspan="<?php echo $this->colspan['right_left']; ?>"><?php _e( 'Dank moms (25,000%)', $this->textdomain ); ?></td>
                <td color="#000" colspan="<?php echo $this->colspan['right_right']; ?>" class="align-right"><?php echo wc_price( $this->order->get_total_discount(), array( 'currency' => $this->order->get_order_currency() ) ); ?></td>
            </tr>
       <?php /*?> <?php } ?><?php */?>
        <!-- Shipping -->
       <?php /*?> <?php if( $this->template_options['bewpi_show_shipping'] ) { ?><?php */?>
            <tr class="shipping after-products">
                <td colspan="<?php echo $this->colspan['left']; ?>"></td>
                <td color="#000" colspan="<?php echo $this->colspan['right_left']; ?>"><?php _e( 'Transfer fee (15,000%)', $this->textdomain ); ?></td>
                <td color="#000" colspan="<?php echo $this->colspan['right_right']; ?>" class="align-right"><?php echo wc_price( $this->order->get_total_shipping(), array( 'currency' => $this->order->get_order_currency() ) ); ?></td>
            </tr>
       <?php /*?> <?php } ?><?php */?>
        <!-- Subtotal -->
       <?php /*?> <?php if( $this->template_options['bewpi_show_subtotal'] && ! (bool)$this->template_options[ 'bewpi_display_prices_incl_tax' ] ) { ?><?php */?>
            <tr class="subtotal after-products">
                <td colspan="<?php echo $this->colspan['left']; ?>"></td>
                <td color="#000" colspan="<?php echo $this->colspan['right_left']; ?>"><?php _e( 'Til udbetaling 30/04/2017', $this->textdomain ); ?></td>
                <td color="#000" colspan="<?php echo $this->colspan['right_right']; ?>" class="align-right"><?php echo wc_price( $this->order->get_subtotal(), array( 'currency' => $this->order->get_order_currency() ) ); ?></td>
            </tr>
       <?php /*?> <?php } ?><?php */?>
       
     </tbody>
    </table>